# CP_Tutorial
DFT - Chemical pressure analysis software package.
For more information, please refer to this paper in Crystal.

The programs in this package is designed to work on a PBS job scheduler. However, for other job schedulers, they can be easily revised to suit the purpose.
